---
title: For users
nav_order: 2
nav_exclude: false
---

# User facing documentation

This documentation sections contains information on how to obtain, configure and troubleshoot SSSD.

## Table of Contents
{% include toc dir='users' %}
