---
title: For developers
nav_order: 3
nav_exclude: false
---

# Developer documentation

This documentation section contains information on how to build, test and release SSSD.

## Table of Contents
{% include toc dir='developers' %}

