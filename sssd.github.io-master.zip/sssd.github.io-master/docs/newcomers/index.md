---
title: Newcomers guide
nav_order: 1
nav_exclude: false
---

# Newcomers Guide

This guide describes the best practices for newcomers who are willing to contribute to the SSSD project, and troubleshoot SSSD.

## Table of Contents
{% include toc dir='newcomers' %}
